#!/bin/bash -       
#==============================================================================

#SBATCH --output=runtile-%j.log    # join the output and error files
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --time=47:00:00
#SBATCH --mem-per-cpu=2G

module load python/booth/3.6/3.6.3
python3 tile.py
